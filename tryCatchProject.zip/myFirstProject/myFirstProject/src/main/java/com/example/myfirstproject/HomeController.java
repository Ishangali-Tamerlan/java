package com.example.myfirstproject;

import javafx.fxml.FXML;
import javafx.scene.layout.AnchorPane;

public class HomeController {

    @FXML
    private AnchorPane imageWaveButton;

}
